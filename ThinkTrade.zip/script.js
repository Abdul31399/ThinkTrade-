document.getElementById("idea-form").addEventListener("submit", function(event) {
    event.preventDefault();
    alert("Idea submitted successfully!");
});